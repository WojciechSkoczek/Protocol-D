# Protocol D — BAO-anchored dipole harness (v0.1)

This is a lightweight reproduction repository for the *harness* used in Protocol D.

What it does:
- compares NULL vs BAO_P1 models for a set of tracer dipoles
- fits a global excess direction `g_hat` and BAO-anchored effective amplitudes `A_eff`
- uses an approximate directional covariance (sigma_mag + sigma_dir proxy)

What it does *not* do:
- it does not re-measure dipoles from raw catalogues (that requires a consistent estimator and detailed mask handling)

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

bash scripts/repro_bao_only.sh
```

Outputs are written to `REPRO_OUT/<timestamp>/`.

## Inputs

Derived input packs are stored under `data/packs/`. They include:
- baseline radio packs (z_radio=1.0)
- packs extended with CatWISE + Quaia (zbins)

## Results

Selected run outputs and summary tables are stored under `results/`.

See `docs/data_provenance.md` for recommended provenance notes to include before making the repo public.
