# HANDOVER — Protocol D (BAO‑anchored dipole) — 2026-02-13 (Europe/Warsaw)

This handover captures the current state of our Protocol‑D work (BAO‑anchored model), the artefacts produced in this chat, and the next steps to continue smoothly in a new thread and in a **public** repository.

## 0) One‑paragraph snapshot

We stabilised the dipole **amplitudes** by switching from a float‑amplitude model to a **BAO‑anchored** model (BAO_P1). After adding **CatWISE AGNs W1<16.5** as tracer #3, amplitudes became tightly aligned (CV(A_eff) ≈ 6%) while **directional scatter persisted** and was dominated by single‑catalogue outliers (LoTSS in one pack, RACS in the other). We then added **Quaia** as tracer #4 (split into parts), introduced conservative direction errors via mask‑scan, and finally built a cleaner Quaia variant using a proper‑motion significance cut (pmSig<2) and **3 redshift bins**. Quaia provides strong z‑leverage but does not, by itself, “fix” direction scatter (it often behaves as an additional direction outlier unless down‑weighted).

## 1) Core claim (current evidence level)

🟢 **Evidence:** BAO‑anchoring acts as a missing scale constraint and yields stable BAO‑anchored amplitudes across tracers (CV ≈ 6%) with strong preference vs NULL (ΔAICc strongly negative).  
🟡 **Evidence:** Direction scatter is tracer‑specific and largely explained by “vector contamination” (mask/footprint/selection) in specific catalogues. (LOO supports this, but note the 2‑tracer degeneracy after LOO.)  
🔵 **Hypothesis:** The “clean” excess vector is physically linked to BAO scale (interpretation, not yet a proof).

## 2) Canonical workflow (what we ran)

1) **Input packs** with fixed z_radio=1.0 (NVSS/LoTSS/RACS) and added tracers (CatWISE, Quaia).  
2) **Harness:** `protocol_d_run_input_pack_any_v2_bao.py` using **BAO_P1 vs NULL**.  
3) **Verdict tables** extracted: ΔAICc, ĝ (l,b), A_eff per tracer, coherence angles.  
4) **LOO diagnosis**: drop one tracer, re‑run, track (i) std(angle), (ii) ĝ shift, (iii) ΔΔAICc.

## 3) Tracer #3: CatWISE AGNs W1<16.5 (merged, canonical)

**Row file:** `protocol_d_row_catwise_agns_w1lt16p5.csv`  
**Merged input packs:**
- `protocol_d_input_pack_boehme2025_lotss_dr2_swap_tier1__zradio_1p0__catwise_w1lt16p5.csv`
- `protocol_d_input_pack_wagenveld2025_tier1__zradio_1p0__catwise_w1lt16p5.csv`

### CatWISE merged results (BAO_P1)

(From `protocol_d_catwise_verdict_tables.md`)

**LoTSSswap — baseline (same as 2MRS_clean):**  
- ΔAICc(BAO_P1−NULL) = **−39.311**  
- ĝ (l,b) = **(230.315°, 19.028°)**  
- CV(A_eff) = **6.0%**  
- Angles: CatWISE 7.87°, NVSS 13.40°, **LoTSS 39.92° (outlier)**

**Wagenveld — baseline:**  
- ΔAICc = **−41.951**  
- ĝ (l,b) = **(238.489°, 35.374°)**  
- CV(A_eff) = **6.0%**  
- Angles: NVSS 6.90°, CatWISE 25.40°, **RACS 53.67° (outlier)**

**Wagenveld — 2MRS_clean:**  
- ΔAICc = **−34.425**  
- ĝ (l,b) = **(236.701°, 36.875°)**  
- CV(A_eff) = **6.0%**  
- Angles: NVSS 10.60°, CatWISE 25.99°, **RACS 60.01° (outlier)**

## 4) LOO (leave‑one‑out) diagnosis summary

File: `protocol_d_direction_loo_ranking.md` (+ CSV).

Key pattern: one tracer dominates direction scatter per pack.  
- LoTSSswap: dropping **LoTSS** reduces std(angle) from 13.99° to 6.10° (Δstd +7.89°).  
- Wagenveld: full‑run outlier is **RACS** (angles 53.67° / 60.01°); dropping RACS reduces std(angle) to ~6–7°.  
Caution: after LOO only 2 tracers remain, so reduced scatter is partly geometrical. Treat LOO as **outlier identification**, not final proof of a unique cosmological axis.

## 5) Tracer #4: Quaia (Gaia–unWISE quasars)

### Data received (split uploads)
- `quaia_G20.0.fits`
- `quaia_G20.5.fits`
- `random_G20.0_10x.fits`
- `random_G20.5_10x.fits`
- `selection_function_NSIDE64_G20.0.fits`
- `selection_function_NSIDE64_G20.5.fits`

### Quaia “cleaner” variant used in packs
We introduced a proper‑motion significance cut to reduce stellar/foreground contamination:
- **pmSig < 2**, with pmSig = sqrt((pmra/σpmra)^2 + (pmdec/σpmdec)^2)

We then defined **3 redshift bins** (treated as 3 independent tracers):
- z∈[0.6,1.0), z∈[1.0,1.5), z∈[1.5,3.0)

We also adopted a conservative, empirical directional uncertainty:
- **σ_dir** derived from mask‑scan sensitivity across |b| ≥ 20/25/30 (maximum separation).

**Row file (binned Quaia, pmSig cut):**  
- `protocol_d_row_quaia_G20p0_pmSiglt2_zbins.csv`

The key columns are already populated: D_obs, D_obs_err, (RA,Dec), (l,b), σ_dir, z_mean.

## 6) Current “latest” packs and run outputs involving Quaia bins

**Input packs (CatWISE + Quaia z‑bins, pmSig<2):**
- `protocol_d_input_pack_wagenveld2025_tier1__zradio_1p0__catwise_w1lt16p5__quaiaG20p0_pmSiglt2_zbins.csv`
- `protocol_d_input_pack_boehme2025_lotss_dr2_swap_tier1__zradio_1p0__catwise_w1lt16p5__quaiaG20p0_pmSiglt2_zbins.csv`

**Run outputs (txt):**
- `protocol_d_run_results_protocol_d_input_pack_wagenveld2025_tier1__zradio_1p0__catwise_w1lt16p5__quaiaG20p0_pmSiglt2_zbins_baseline.txt`
- `protocol_d_run_results_protocol_d_input_pack_wagenveld2025_tier1__zradio_1p0__catwise_w1lt16p5__quaiaG20p0_pmSiglt2_zbins_2MRS_clean.txt`
- `protocol_d_run_results_protocol_d_input_pack_boehme2025_lotss_dr2_swap_tier1__zradio_1p0__catwise_w1lt16p5__quaiaG20p0_pmSiglt2_zbins_baseline.txt`
- `protocol_d_run_results_protocol_d_input_pack_boehme2025_lotss_dr2_swap_tier1__zradio_1p0__catwise_w1lt16p5__quaiaG20p0_pmSiglt2_zbins_2MRS_clean.txt`

**Bundles:**
- `protocol_d_catwise_run_bundle.zip` (CatWISE merged runs + tables)
- `protocol_d_quaiaG20p0_pmSiglt2_bundle.zip` (Quaia pmSig<2 artefacts)
- `protocol_d_repo_skeleton_v0_1.zip` (public repo skeleton)

## 7) Public repository (v0.1) status and what still needs doing

We created a repo skeleton:
- Folder: `protocol_d_repo_skeleton_v0_1/`
- Zip: `protocol_d_repo_skeleton_v0_1.zip`

### Repo v0.1 is ready if we do these finishing touches
🟢 Add provenance metadata:
- For each tracer row, clearly mark whether (D, l, b) is **paper‑quoted** or **re‑measured here** (and with which mask and debias method).
- For Quaia rows, fix the “reference” field to the correct dataset/paper citation (currently placeholder‑ish).

🟢 Data policy for public repo:
- Keep large FITS out of Git. Provide `data/README.md` with download instructions, file names, and SHA256 checksums.
- Decide on Git LFS or DVC (optional). Minimal approach is “manual download + checksums”.

🟢 Repro commands:
- Ensure `repro.sh` / `repro.ps1` call the **correct** harness filename (`protocol_d_run_input_pack_any_v2_bao.py`) and point to the included packs.

🟡 Limitations section:
- State explicitly that direction results can be tracer‑specific and mask‑sensitive.
- State that LOO reduces the system to 2 tracers and must be interpreted accordingly.

## 8) “Next steps” checklist for the next chat

1) Generate the **CMB comparison plot** (ĝ vs Planck dipole, with cones), and compute Δθ for each run.  
2) Build the **Robustness plateau** figure(s): scan |b| cuts and flux/mag thresholds and track (CV(A_eff), ΔAICc, shift(ĝ)).  
3) Decide how Quaia enters the main narrative:
   - amplitude‑only (down‑weight direction), or
   - keep direction but with empirical σ_dir and show it as “systematics‑limited”.
4) Repo polish:
   - provenance table, licences (verify), CITATION.cff, Zenodo DOI later if desired.

## 9) Quick file index (everything produced in this chat)

Key scripts:  
- `protocol_d_run_input_pack_any_v2_bao.py`  
- `make_zradio_csv.py`  
- `repro.sh`, `repro.ps1`  

Key tables:  
- `protocol_d_catwise_verdict_tables.md`  
- `protocol_d_direction_loo_ranking.md` (+ CSV)  
- `protocol_d_row_catwise_agns_w1lt16p5.csv`  
- `protocol_d_row_quaia_G20p0_pmSiglt2_zbins.csv`

Key packs:  
- base packs: `protocol_d_input_pack_*__zradio_1p0.csv`  
- with CatWISE: `...__catwise_w1lt16p5.csv`  
- with CatWISE + Quaia z‑bins: `...__quaiaG20p0_pmSiglt2_zbins.csv`

Bundles:  
- `protocol_d_catwise_run_bundle.zip`  
- `protocol_d_quaiaG20p0_pmSiglt2_bundle.zip`  
- `protocol_d_repo_skeleton_v0_1.zip`
