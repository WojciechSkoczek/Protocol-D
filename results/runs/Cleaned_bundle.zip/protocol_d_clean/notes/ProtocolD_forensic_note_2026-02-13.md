# Protocol D — quick forensic note (2026-02-13)

## Why the bootstrap plots look “off”
The bootstrap figures (mean directions around **(243.7°, 33.8°)** for LoTSS swap and **(251.9°, 45.4°)** for Wagenveld) sit almost exactly *halfway between* two *different* fitted solutions:

- **CatWISE-only** solutions:
  - LoTSS swap: ĝ = (230.315°, 19.028°)  (Δ to CMB ≈ 39.9°)
  - Wagenveld:  ĝ = (238.489°, 35.374°)  (Δ to CMB ≈ 22.8°)

- **Quaia z-bins added** solutions:
  - LoTSS swap: ĝ = (256.798°, 44.302°)  (Δ to CMB ≈ 6.36°)
  - Wagenveld:  ĝ = (263.192°, 51.117°)  (Δ to CMB ≈ 2.91°)

A simple midpoint check:
- (230.3 + 256.8)/2 ≈ 243.6 and (19.0 + 44.3)/2 ≈ 31.6  → matches the LoTSS bootstrap mean direction.
- (238.5 + 263.2)/2 ≈ 250.9 and (35.4 + 51.1)/2 ≈ 43.2  → matches the Wagenveld bootstrap mean direction.

**Interpretation:** the bootstrap script almost certainly mixed *CatWISE-only* and *Quaia-zbins* result files in one pool (a bookkeeping artefact, not a physical result). Run bootstrap separately for each pack type.

## “Amplitude instability” is a metric issue (for Quaia z-bins)
For the Quaia z-bins runs, **CV(A_eff)** is expected to be large because **A_eff ∝ 1/χ(z)** in the BAO-anchored model.

A better consistency check across mixed redshifts is:
- **K_i = χ_i · A_eff,i**  (should be constant ≈ β·r_bao)

In the runs we have, **CV(χ·A_eff)** is ~1e-4% (essentially perfect), confirming the anchoring works as intended.

## Next clean steps
1. Keep two separate run folders:
   - `runs/catwise_only/`
   - `runs/quaia_zbins/`
2. Regenerate bootstrap separately per folder.
3. In bootstrap summary, replace `CV(A_eff)` with `CV(χ·A_eff)` (or just track β stability).
